/*********************************************************************
* FileName:        PIC16F1937 Bootloader.Designer.cs
* Dependencies:    See INCLUDES section below
* Processor:       
* Compiler:        
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro?Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description:
*
* Change History:
* Author               Cristian Toma
********************************************************************/
namespace _1937_Bootloader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.DisplayBox = new System.Windows.Forms.RichTextBox();
            this.Display_Erase_conMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.NewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ImportHexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportHexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bootloaderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eraseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runFirmwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Erase_Thread = new System.ComponentModel.BackgroundWorker();
            this.ProgMemView = new System.Windows.Forms.ListView();
            this.Program_Thread = new System.ComponentModel.BackgroundWorker();
            this.Read_Thread = new System.ComponentModel.BackgroundWorker();
            this.Display_Erase_conMenu.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DisplayBox
            // 
            this.DisplayBox.ContextMenuStrip = this.Display_Erase_conMenu;
            this.DisplayBox.Location = new System.Drawing.Point(16, 31);
            this.DisplayBox.Margin = new System.Windows.Forms.Padding(4);
            this.DisplayBox.Name = "DisplayBox";
            this.DisplayBox.Size = new System.Drawing.Size(515, 102);
            this.DisplayBox.TabIndex = 0;
            this.DisplayBox.Text = "";
            this.DisplayBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // Display_Erase_conMenu
            // 
            this.Display_Erase_conMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Display_Erase_conMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem});
            this.Display_Erase_conMenu.Name = "Display_Erase_conMenu";
            this.Display_Erase_conMenu.Size = new System.Drawing.Size(115, 28);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(114, 24);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(17, 140);
            this.progressBar.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(515, 26);
            this.progressBar.Step = 1;
            this.progressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBar.TabIndex = 8;
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Hex files (*.hex)|*.hex|All files (*.*)|*.*\"";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.bootloaderToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1020, 27);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NewToolStripMenuItem,
            this.ImportHexToolStripMenuItem,
            this.exportHexToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(47, 23);
            this.toolStripMenuItem1.Text = "File";
            // 
            // NewToolStripMenuItem
            // 
            this.NewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("NewToolStripMenuItem.Image")));
            this.NewToolStripMenuItem.Name = "NewToolStripMenuItem";
            this.NewToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.NewToolStripMenuItem.Text = "New";
            this.NewToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // ImportHexToolStripMenuItem
            // 
            this.ImportHexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ImportHexToolStripMenuItem.Image")));
            this.ImportHexToolStripMenuItem.Name = "ImportHexToolStripMenuItem";
            this.ImportHexToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.ImportHexToolStripMenuItem.Text = "Import Hex";
            this.ImportHexToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // exportHexToolStripMenuItem
            // 
            this.exportHexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exportHexToolStripMenuItem.Image")));
            this.exportHexToolStripMenuItem.Name = "exportHexToolStripMenuItem";
            this.exportHexToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.exportHexToolStripMenuItem.Text = "Export Hex";
            this.exportHexToolStripMenuItem.Click += new System.EventHandler(this.exportHexToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // bootloaderToolStripMenuItem
            // 
            this.bootloaderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.readToolStripMenuItem,
            this.eraseToolStripMenuItem,
            this.programToolStripMenuItem,
            this.runFirmwareToolStripMenuItem});
            this.bootloaderToolStripMenuItem.Name = "bootloaderToolStripMenuItem";
            this.bootloaderToolStripMenuItem.Size = new System.Drawing.Size(100, 23);
            this.bootloaderToolStripMenuItem.Text = "Bootloader";
            // 
            // readToolStripMenuItem
            // 
            this.readToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("readToolStripMenuItem.Image")));
            this.readToolStripMenuItem.Name = "readToolStripMenuItem";
            this.readToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.readToolStripMenuItem.Text = "Read";
            this.readToolStripMenuItem.Click += new System.EventHandler(this.readToolStripMenuItem_Click);
            // 
            // eraseToolStripMenuItem
            // 
            this.eraseToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("eraseToolStripMenuItem.Image")));
            this.eraseToolStripMenuItem.Name = "eraseToolStripMenuItem";
            this.eraseToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.eraseToolStripMenuItem.Text = "Erase";
            this.eraseToolStripMenuItem.Click += new System.EventHandler(this.eraseToolStripMenuItem_Click);
            // 
            // programToolStripMenuItem
            // 
            this.programToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("programToolStripMenuItem.Image")));
            this.programToolStripMenuItem.Name = "programToolStripMenuItem";
            this.programToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.programToolStripMenuItem.Text = "Program";
            this.programToolStripMenuItem.Click += new System.EventHandler(this.programToolStripMenuItem_Click);
            // 
            // runFirmwareToolStripMenuItem
            // 
            this.runFirmwareToolStripMenuItem.Name = "runFirmwareToolStripMenuItem";
            this.runFirmwareToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.runFirmwareToolStripMenuItem.Text = "Run Firmware";
            this.runFirmwareToolStripMenuItem.Click += new System.EventHandler(this.runFirmwareToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(65, 23);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // Erase_Thread
            // 
            this.Erase_Thread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Erase_Thread_DoWork);
            // 
            // ProgMemView
            // 
            this.ProgMemView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.ProgMemView.HideSelection = false;
            this.ProgMemView.Location = new System.Drawing.Point(13, 174);
            this.ProgMemView.Margin = new System.Windows.Forms.Padding(4);
            this.ProgMemView.Name = "ProgMemView";
            this.ProgMemView.Size = new System.Drawing.Size(994, 319);
            this.ProgMemView.TabIndex = 16;
            this.ProgMemView.UseCompatibleStateImageBehavior = false;
            // 
            // Program_Thread
            // 
            this.Program_Thread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Program_Thread_DoWork);
            // 
            // Read_Thread
            // 
            this.Read_Thread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Read_Thread_DoWork);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1020, 504);
            this.Controls.Add(this.ProgMemView);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.DisplayBox);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "PIC18F16Q40 I2C Bootloader";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Display_Erase_conMenu.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox DisplayBox;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem NewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ImportHexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportHexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bootloaderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem readToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eraseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker Erase_Thread;
        private System.Windows.Forms.ListView ProgMemView;
        private System.ComponentModel.BackgroundWorker Program_Thread;
        private System.ComponentModel.BackgroundWorker Read_Thread;
        private System.Windows.Forms.ContextMenuStrip Display_Erase_conMenu;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runFirmwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    }
}

