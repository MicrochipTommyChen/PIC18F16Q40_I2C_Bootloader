/*********************************************************************
* FileName:		   DeviceData.cs 
* Dependencies:    See INCLUDES section below
* Processor:       
* Compiler:        
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro?Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description:
*
* Change History:
* Author               Cristian Toma
********************************************************************/
using System;
using System.Collections.Generic;
using System.Text;

namespace _1937_Bootloader
{
    public class DeviceData
    {
        public uint[] ProgramMemory;
        public uint[] EEPromMemory;
        public uint[] ConfigWords;
        public uint[] UserIDs;

        public DeviceData(uint progMemSize, ushort eeMemSize, byte numConfigs, byte numIDs,
                            uint memBlankVal, int eeBytes, int idBytes)
        {   // Overloaded Constructor
            ProgramMemory = new uint[progMemSize];
            EEPromMemory = new uint[eeMemSize];
            ConfigWords = new uint[numConfigs];
            UserIDs = new uint[numIDs];

            //init program memory to blank
            //ClearProgramMemory(memBlankVal);

            //init eeprom to blank
            //ClearEEPromMemory(eeBytes, memBlankVal);

            ////init configuration to blank
            //ClearConfigWords(configBlank);

            //init user ids to blank
            //ClearUserIDs(idBytes, memBlankVal);

            ////init OSSCAL & BandGap
            //OSCCAL = OSCCALInit | 0xFF;
            //BandGap = memBlankVal;

        }

        public void ClearProgramMemory(uint memBlankVal)
        {
            if (ProgramMemory.Length > 0)
            {
                for (int i = 0; i < ProgramMemory.Length; i++)
                {
                    ProgramMemory[i] = memBlankVal;
                }
            }
        }


    //    public void ClearConfigWords(ushort[] configBlank)
    //    {
    //        if (ConfigWords.Length > 0)
    //        {
    //            //init configuration to blank
    //            for (int i = 0; i < ConfigWords.Length; i++)
    //            {
    //                ConfigWords[i] = configBlank[i];
    //            }
    //        }
    //    }

        public void ClearUserIDs(int idBytes, uint memBlankVal)
        {
            if (UserIDs.Length > 0)
            {
                //init user ids to blank
                uint idBlank = memBlankVal;
                if (idBytes == 1)
                {
                    idBlank = 0xFF;
                }
                for (int i = 0; i < UserIDs.Length; i++)
                {
                    UserIDs[i] = idBlank;
                }
            }
        }

        public void ClearEEPromMemory(int eeBytes, uint memBlankVal)
        {
            if (EEPromMemory.Length > 0)
            {
                //init eeprom to blank
                uint eeBlankVal = 0xFF;
                if (eeBytes == 2)
                {
                    eeBlankVal = 0xFFFF;
                }
                if (memBlankVal == 0xFFF)
                { // baseline dataflash
                    eeBlankVal = 0xFFF;
                }
                for (int i = 0; i < EEPromMemory.Length; i++)
                {
                    EEPromMemory[i] = eeBlankVal;                  // 8-bit eeprom will just use 8 LSBs
                }
            }
        }        
    }
}
