﻿/*********************************************************************
* FileName:        BootloadModule.cs
* Dependencies:    See INCLUDES section below
* Processor:       
* Compiler:        
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro® Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description:
*
* Change History:
* Author               Cristian Toma
********************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
namespace _1937_Bootloader
{
    class Bootload
    {
        public static bool InitTransport(int transport)
        {
            if (PICkitS.Basic.Initialize_PICkitSerial())
            {
                if (PICkitS.I2CM.Configure_PICkitSerial_For_I2CMaster())
                {
                    PICkitS.Basic.Reset_Control_Block();
                    PICkitS.I2CM.Set_I2C_Bit_Rate(400000);
                    PICkitS.I2CM.Set_Receive_Wait_Time(200);
                    return true;
                }
                return false;
            }
            return false;
        }
        public static bool Set_Address_Pointer(int address)
        {
            //Ken:2021/05/31
            //Old:For PIC16F1937
            //byte slave_address = 0xA0;      // device's address
            //New:
            //S=================================================
            byte slave_address = 0x30;      // device's address
            //E=================================================
            byte word_address = 0x01;       // word address for tx buffer
            byte[] DataArray = new byte[2];
            byte bytes_to_write = 0x02;
            string Return_Str = "";


            byte Byte0 = (byte)(address >> 8);        // high byte
            byte Byte1 = (byte)(address & 0xFF);      // low  byte

            DataArray[0] = Byte0;
            DataArray[1] = Byte1;
            try
            {
                if (PICkitS.I2CM.Write(slave_address, word_address, bytes_to_write, ref DataArray, ref Return_Str))
                {
                }
                else
                {
                    PICkitS.Basic.Reset_Control_Block(); //   clear any errors in PKSA
                    return false;
                }
            }
            catch
            {
                return false;
            }

            return true;
        }
        public static bool Get_Address_Pointer(ref int address)
        {

            //Ken:2021/05/31
            //Old:For PIC16F1937
            //byte slave_address = 0xA0;      // device's address
            //New:
            //S=================================================
            byte slave_address = 0x30;      // device's address
            //E=================================================
            byte word_address = 0x01;       // word address for tx buffer
            byte[] DataArray = new byte[2];
            byte bytes_to_read = 0x02;
            string Return_Str = "";
            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                    address = DataArray[0] * 256 + DataArray[1];
                }
                else
                {
                   return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }

            return true;
        }
        public static bool Read_Data(ref int[] data)
        {
            //Ken:2021/05/31
            //Old:For PIC16F1937
            //byte slave_address = 0xA0;      // device's address
            //New:
            //S=================================================
            byte slave_address = 0x30;      // device's address
            //E=================================================
            byte word_address = 0x03;       // read flash command
            //Ken:2021/05/05, 2021/05/24
            //Old:
            //byte[] DataArray = new byte[64];
            //byte bytes_to_read = 16;
            //New:
            //S=================================
            byte[] DataArray = new byte[128];
            byte bytes_to_read = 128; //128 Bytes
            byte read_index = 0;
            //E=================================
            string Return_Str = "";

            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                    //Ken:2021/05/05, 2021/05/24          
                    //Expand from 8 words(16 Bytes) to 64 words(128 Bytes)
                    /*
                    data[0] = DataArray[0] * 256 + DataArray[1];
                    data[1] = DataArray[2] * 256 + DataArray[3];
                    data[2] = DataArray[4] * 256 + DataArray[5];
                    data[3] = DataArray[6] * 256 + DataArray[7];
                    data[4] = DataArray[8] * 256 + DataArray[9];
                    data[5] = DataArray[10] * 256 + DataArray[11];
                    data[6] = DataArray[12] * 256 + DataArray[13];
                    data[7] = DataArray[14] * 256 + DataArray[15];
                    //New:
                    //S============================================
                    data[8] = DataArray[16] * 256 + DataArray[17];
                    data[9] = DataArray[18] * 256 + DataArray[19];
                    data[10] = DataArray[20] * 256 + DataArray[21];
                    data[11] = DataArray[22] * 256 + DataArray[23];
                    data[12] = DataArray[24] * 256 + DataArray[25];
                    data[13] = DataArray[26] * 256 + DataArray[27];
                    data[14] = DataArray[28] * 256 + DataArray[29];
                    data[15] = DataArray[30] * 256 + DataArray[31];
                    data[16] = DataArray[32] * 256 + DataArray[33];
                    data[17] = DataArray[34] * 256 + DataArray[35];
                    data[18] = DataArray[36] * 256 + DataArray[37];
                    data[19] = DataArray[38] * 256 + DataArray[39];
                    data[20] = DataArray[40] * 256 + DataArray[41];
                    data[21] = DataArray[42] * 256 + DataArray[43];
                    data[22] = DataArray[44] * 256 + DataArray[45];
                    data[23] = DataArray[46] * 256 + DataArray[47];
                    data[24] = DataArray[48] * 256 + DataArray[49];
                    data[25] = DataArray[50] * 256 + DataArray[51];
                    data[26] = DataArray[52] * 256 + DataArray[53];
                    data[27] = DataArray[54] * 256 + DataArray[55];
                    data[28] = DataArray[56] * 256 + DataArray[57];
                    data[29] = DataArray[58] * 256 + DataArray[59];
                    data[30] = DataArray[60] * 256 + DataArray[61];
                    data[31] = DataArray[62] * 256 + DataArray[63];
                    */
                    //Ken:2021/05/28
                    //Expand to 128 Bytes (PIC18F16Q40 Byte-Address)
                    //S====================================================================================
                    for(read_index = 0; read_index < 128; read_index++)
                    {
                        //Ken:2021/05/28
                        //DataArray[0x600] should be = 0xEF, 0x5D
                        //Swap 0x5D -> Data[0] & 0xEF -> Data[1]
                        if (read_index % 2 == 0)
                        {
                            data[read_index] = (DataArray[read_index + 1]);
                            data[read_index] &= 0xFF;
                        }
                        else if (read_index % 2 == 1) 
                        {
                            data[read_index] = (DataArray[read_index - 1]);
                            data[read_index] &= 0xFF;
                        }
                    }
                    //E====================================================================================
                }
                else
                {
                    return false;
                }
            } 
            catch
            {
                    PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                    return false;
            }
            return true;
        }
        public static bool Erase_Cycle()
        {
            //Ken:2021/05/31
            //Old:For PIC16F1937
            //byte slave_address = 0xA0;      // device's address
            //New:
            //S=================================================
            byte slave_address = 0x30;      // device's address
            //E=================================================
            byte word_address = 0x04;       // word address for tx buffer
            //Ken:2021/05/26
            //Modification as 256
            byte[] DataArray = new byte[256];
            byte bytes_to_read = 1;
            string Return_Str = "";

            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }
            return true;
        }
        public static bool Write_Cycle()
        {
            //Ken:2021/05/31
            //Old:For PIC16F1937
            //byte slave_address = 0xA0;      // device's address
            //New:
            //S=================================================
            byte slave_address = 0x30;      // device's address
            //E=================================================
            byte word_address = 0x05;       // write command
            //Ken:2021/05/26
            //New:For PIC18F16Q40 -> Write 128 Bytes each times
            byte[] DataArray = new byte[128];
            byte bytes_to_read = 1;
            string Return_Str = "";

            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }
            return true;

        }
        public static bool Send_Data_Chunk(uint[] data, int address)
        {
            //Ken:2021/05/31
            //Old:For PIC16F1937
            //byte slave_address = 0xA0;      // device's address
            //New:
            //S=================================================
            byte slave_address = 0x30;      // device's address
            //E=================================================
            byte word_address = 0x02;       // download 8 word to buffer
            //Ken:2021/05/10, 2021/05/26
            //Old:For PIC16F1937
            //byte bytes_to_write = 16;
            //New:For PIC18F16Q40
            //S=======================
            byte bytes_to_write = 128;       // download 128 bytes to buffer
            //E=======================
            string Return_Str = "";
            byte[] Array = new byte[128];
            //Ken:2021/05/24
            //S===================================
            byte Write_Index = 0;  //Maxima = 255
            //E===================================

            //Ken:2021/05/05, 2021/05/24
            //Expand from 8 words(16 Bytes) to 32 words(64 Bytes)
            /*
            Array[0] = Convert.ToByte(data[address + 0] >> 8);
            Array[1] = Convert.ToByte(data[address + 0] & 0xFF);
            Array[2] = Convert.ToByte(data[address + 1] >> 8);
            Array[3] = Convert.ToByte(data[address + 1] & 0xFF);
            Array[4] = Convert.ToByte(data[address + 2] >> 8);
            Array[5] = Convert.ToByte(data[address + 2] & 0xFF);
            Array[6] = Convert.ToByte(data[address + 3] >> 8);
            Array[7] = Convert.ToByte(data[address + 3] & 0xFF);
            Array[8] = Convert.ToByte(data[address + 4] >> 8);
            Array[9] = Convert.ToByte(data[address + 4] & 0xFF);
            Array[10] = Convert.ToByte(data[address + 5] >> 8);
            Array[11] = Convert.ToByte(data[address + 5] & 0xFF);
            Array[12] = Convert.ToByte(data[address + 6] >> 8);
            Array[13] = Convert.ToByte(data[address + 6] & 0xFF);
            Array[14] = Convert.ToByte(data[address + 7] >> 8);
            Array[15] = Convert.ToByte(data[address + 7] & 0xFF);
            //New:
            //S===================================================
            Array[16] = Convert.ToByte(data[address + 8] >> 8);
            Array[17] = Convert.ToByte(data[address + 8] & 0xFF);
            Array[18] = Convert.ToByte(data[address + 9] >> 8);
            Array[19] = Convert.ToByte(data[address + 9] & 0xFF);
            Array[20] = Convert.ToByte(data[address + 10] >> 8);
            Array[21] = Convert.ToByte(data[address + 10] & 0xFF);
            Array[22] = Convert.ToByte(data[address + 11] >> 8);
            Array[23] = Convert.ToByte(data[address + 11] & 0xFF);
            Array[24] = Convert.ToByte(data[address + 12] >> 8);
            Array[25] = Convert.ToByte(data[address + 12] & 0xFF);
            Array[26] = Convert.ToByte(data[address + 13] >> 8);
            Array[27] = Convert.ToByte(data[address + 13] & 0xFF);
            Array[28] = Convert.ToByte(data[address + 14] >> 8);
            Array[29] = Convert.ToByte(data[address + 14] & 0xFF);
            Array[30] = Convert.ToByte(data[address + 15] >> 8);
            Array[31] = Convert.ToByte(data[address + 15] & 0xFF);
            Array[32] = Convert.ToByte(data[address + 16] >> 8);
            Array[33] = Convert.ToByte(data[address + 16] & 0xFF);
            Array[34] = Convert.ToByte(data[address + 17] >> 8);
            Array[35] = Convert.ToByte(data[address + 17] & 0xFF);
            Array[36] = Convert.ToByte(data[address + 18] >> 8);
            Array[37] = Convert.ToByte(data[address + 18] & 0xFF);
            Array[38] = Convert.ToByte(data[address + 19] >> 8);
            Array[39] = Convert.ToByte(data[address + 19] & 0xFF);
            Array[40] = Convert.ToByte(data[address + 20] >> 8);
            Array[41] = Convert.ToByte(data[address + 20] & 0xFF);
            Array[42] = Convert.ToByte(data[address + 21] >> 8);
            Array[43] = Convert.ToByte(data[address + 21] & 0xFF);
            Array[44] = Convert.ToByte(data[address + 22] >> 8);
            Array[45] = Convert.ToByte(data[address + 22] & 0xFF);
            Array[46] = Convert.ToByte(data[address + 23] >> 8);
            Array[47] = Convert.ToByte(data[address + 23] & 0xFF);
            Array[48] = Convert.ToByte(data[address + 24] >> 8);
            Array[49] = Convert.ToByte(data[address + 24] & 0xFF);
            Array[50] = Convert.ToByte(data[address + 25] >> 8);
            Array[51] = Convert.ToByte(data[address + 25] & 0xFF);
            Array[52] = Convert.ToByte(data[address + 26] >> 8);
            Array[53] = Convert.ToByte(data[address + 26] & 0xFF);
            Array[54] = Convert.ToByte(data[address + 27] >> 8);
            Array[55] = Convert.ToByte(data[address + 27] & 0xFF);
            Array[56] = Convert.ToByte(data[address + 28] >> 8);
            Array[57] = Convert.ToByte(data[address + 28] & 0xFF);
            Array[58] = Convert.ToByte(data[address + 29] >> 8);
            Array[59] = Convert.ToByte(data[address + 29] & 0xFF);
            Array[60] = Convert.ToByte(data[address + 30] >> 8);
            Array[61] = Convert.ToByte(data[address + 30] & 0xFF);
            Array[62] = Convert.ToByte(data[address + 31] >> 8);
            Array[63] = Convert.ToByte(data[address + 31] & 0xFF);
            */
            //Expand from 32 words(64 Bytes) to 128 Bytes -> PIC18F16Q40
            //S==========================================================================
            for(Write_Index=0; Write_Index<128; Write_Index++)
            {
                Array[Write_Index] = Convert.ToByte(data[address + Write_Index] & 0xFF);
            }
            //E==========================================================================

            try
            {
                if (PICkitS.I2CM.Write(slave_address, word_address, bytes_to_write, ref Array, ref Return_Str))
                {
                    return true;
                }
                else
                {
                    PICkitS.Basic.Reset_Control_Block(); //   clear any errors in PKSA
                    return false;
                }
            }
            catch
            {
                return false;
            }           
        }
        public static bool Verify_Data_Chunk(uint[] data, int address, ref int  errorAddress)
        {
            //Ken:2021/05/05
            //Old: PIC16F1937
            //int[] DataArray = new int[8];
            //New: PIC16F18446
            //S=============================
            //int[] DataArray = new int[32];  // Read 32 Words each times
            //E=============================
            //Ken:2021/05/26
            //New: For PIC18F16Q40
            //S==============================
            int[] DataArray = new int[128];  // Read 128 Bytes each times
            //E==============================
            byte a = 0;
            bool result =  true;

            Read_Data(ref DataArray);
            //Ken:2021/05/05
            //Old: PIC16F1937
            //for (a = 0; a <= 7; a++)  // Read 8 words
            //New: PIC16F18446
            //S===========================
            //for (a = 0; a <= 31; a++)   // Read 32 words
            //E===========================
            //Ken:2021/05/26
            //New: For PIC18F16Q40
            //S=============================
            for (a = 0; a <= 127; a++)   // Read 128 Bytes
            //E=============================
            {
                //Ken:2021/05/31
                //New: 0xFF5D -> 0x005D
                if ((data[address + a] &= 0xFF) == DataArray[a])
                {

                }
                else
                {
                    errorAddress = address + a;
                    //MessageBox.Show("address + a = " + (address + a ));
                    //MessageBox.Show("a " + DataArray[a]);
                    result = false;
                    break;
                }
            }
            return result;
        }
        public static bool Go_To_App_Mode()
        {
            //Ken:2021/05/31
            //Old:For PIC16F1937
            //byte slave_address = 0xA0;      // device's address
            //New:
            //S=================================================
            byte slave_address = 0x30;      // device's address
            //E=================================================
            byte word_address = 0x06;       // jump to application code
            byte[] DataArray = new byte[64];
            byte bytes_to_read = 1;
            string Return_Str = "";


            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }
        }
    }
}
