/*********************************************************************
* FileName:        PIC16F1937 Bootloader.c 
* Dependencies:    See INCLUDES section below
* Processor:       
* Compiler:        
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description:
*
* Change History:
* Author               Cristian Toma
********************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace _1937_Bootloader
{
    public partial class Form1 : Form
    {
        const int START_ADDR= 0x0200;
        const int STOP_ADDR = 0x1FFF;

        //[DllImport("user32.dll", EntryPoint = "HideCaret")]
        //public static extern long HideCaret(IntPtr hwnd);

        #region Form
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {


            if (Bootload.InitTransport(0))      // dummy number, for future use
            {
                DisplayBox.Text += "PKSA configured for I2C master" + "\n";
            }
            else
            {
                MessageBox.Show("PICkit Serial not found. Program cannot continue.");
            }

            try
            {
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearProgramMemory(0x3FFF);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearEEPromMemory(1, 0xFF);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearUserIDs(0, 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not initialize buffers. Error says:" + ex.Message);
            }


            // first just init the ListView
            ProgMemView.Columns.Add("Address", 70, HorizontalAlignment.Left);
            ProgMemView.Columns.Add("Data", 296, HorizontalAlignment.Left);
            ProgMemView.View = View.Details;
            ProgMemView.Font = new Font(ProgMemView.Font, ProgMemView.Font.Style | FontStyle.Bold);
            ProgMemView.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));

            UpdateMemoryWindow();
            //HideCaret(DisplayBox.Handle);

        }
        private void textChanged(object sender, EventArgs e)
        {
            //DisplayBox.SelectionLength = 0;
            //DisplayBox.SelectionStart = DisplayBox.Text.Length;
            //DisplayBox.ScrollToCaret();
            //HideCaret(DisplayBox.Handle);
        }
        private void WorkingStatus(bool show, int somedata)
        {
            string[] str = new string[4];
            str[0] = "-";
            str[1] = "\\";
            str[2] = "|";
            str[3] = "/";

            if (DisplayBox.Text.Length > 0)
                DisplayBox.Text = DisplayBox.Text.Remove(DisplayBox.Text.Length - 1, 1);
            if (show)
                DisplayBox.Text += str[somedata % 4];
        }
        private void UpdateMemoryWindow()
        {
            ProgMemView.Items.Clear();

            for (int i = START_ADDR; i < STOP_ADDR; i += 8)
            {
                ListViewItem Item = new ListViewItem("0x" + Convert.ToString(i, 16).PadLeft(4, '0'));
                Item.SubItems.Add(
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 0], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 1], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 2], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 3], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 4], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 5], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 6], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 7], 16).PadLeft(4, '0')
                    );
                ProgMemView.Items.Add(Item);
            }

        }
        #endregion
        #region MenuItems
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // We must first "erase" the buffers to default unprogrammed values
            _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearProgramMemory(0x3FFF);
            _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearEEPromMemory(1, 0xFF);
            _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearUserIDs(0, 0);

            ProgMemView.Items.Clear();

            for (int i = 0; i < _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory.Length; i += 8)
            {
                ListViewItem Item = new ListViewItem("0x" + Convert.ToString(i, 16).PadLeft(4, '0'));
                Item.SubItems.Add(
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 0], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 1], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 2], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 3], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 4], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 5], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 6], 16).PadLeft(4, '0') + " " +
                    Convert.ToString(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[i + 7], 16).PadLeft(4, '0')

                    );
                ProgMemView.Items.Add(Item);
            }
        }
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Hex files (*.hex)|*.hex|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;

            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {

                    // We must first "erase" the buffers to default unprogrammed values
                    _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearProgramMemory(0x3FFF);
                    _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearEEPromMemory(1, 0xFF);
                    _1937_Bootloader.ImportExportHex.DeviceBuffers.ClearUserIDs(0, 0);
                    _1937_Bootloader.ImportExportHex.ImportHexFile(openFileDialog.FileName);
                    UpdateMemoryWindow();
                    DisplayBox.Text+=("Loaded " +openFileDialog.FileName + Environment.NewLine);
                    if (_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[STOP_ADDR] != 0x3455)
                    {
                        MessageBox.Show("WARNING :  The flag that indicates an application is loaded is missing. The application cannot run without this flag.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
            }

        }
        private void exportHexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            saveFileDialog1.Filter = "Hex files (*.hex)|*.hex|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _1937_Bootloader.ImportExportHex.ExportHexFile(saveFileDialog1.FileName, true, true);
                    DisplayBox.Text += "Saved to " + saveFileDialog1.FileName + Environment.NewLine;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }
        private void programToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!Erase_Thread.IsBusy & !Program_Thread.IsBusy & !Read_Thread.IsBusy)
                Program_Thread.RunWorkerAsync();
        }
        private void eraseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!Erase_Thread.IsBusy & !Program_Thread.IsBusy & !Read_Thread.IsBusy)
            Erase_Thread.RunWorkerAsync();

        }
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DisplayBox.Clear();
        }
        private void runFirmwareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!Erase_Thread.IsBusy & !Program_Thread.IsBusy & !Read_Thread.IsBusy)
            {
                DisplayBox.Text += "Going to application mode.\n";
                Bootload.Go_To_App_Mode();
            }
            return ;
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About licenseBox = new About();
            licenseBox.ShowDialog();
        }
        private void readToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (!Erase_Thread.IsBusy & !Program_Thread.IsBusy & !Read_Thread.IsBusy)
                Read_Thread.RunWorkerAsync();
        }
        #endregion
        #region Threads
        private void Erase_Thread_DoWork(object sender, DoWorkEventArgs e)
        {
            DisplayBox.Text += "Erasing ..." +Environment.NewLine ;

            EraseAll();
        }
        private void Read_Thread_DoWork(object sender, DoWorkEventArgs e)
        {
            int[] Array = new int[64];


            progressBar.Maximum = STOP_ADDR - 1;
            progressBar.Minimum = START_ADDR ;

            DisplayBox.Text += "Reading ..." + Environment.NewLine;
            Bootload.Set_Address_Pointer(START_ADDR);
            for (int a = START_ADDR; a < STOP_ADDR; a += 8)
            {
                Bootload.Read_Data(ref Array);
                progressBar.Value = a;
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+0] = Convert.ToUInt16(Array[0]);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+1] = Convert.ToUInt16(Array[1]);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+2] = Convert.ToUInt16(Array[2]);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+3] = Convert.ToUInt16(Array[3]);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+4] = Convert.ToUInt16(Array[4]);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+5] = Convert.ToUInt16(Array[5]);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+6] = Convert.ToUInt16(Array[6]);
                _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[a+7] = Convert.ToUInt16(Array[7]);
                WorkingStatus(true, a / 8);
            }
            WorkingStatus(false, 0);
            DisplayBox.Text += "done." + Environment.NewLine;
            ProgMemView.BeginUpdate();
            UpdateMemoryWindow();
            ProgMemView.EndUpdate();
            progressBar.Value = START_ADDR;
        }
        private void Program_Thread_DoWork(object sender, DoWorkEventArgs e)
        {
            int write_start = START_ADDR;
            int write_stop = START_ADDR;
            int write_pointer = START_ADDR;


            DisplayBox.Text += "Erasing...\n";
            EraseAll();

             //some smart technique, write only where there is data
             //find the last address that contains data

             //Count until STOP_ADDR -1 , leaving out the application loaded flag
             //Will program the application load flag only after the verify step
            for ( write_pointer = START_ADDR; write_pointer <= STOP_ADDR - 8  ; write_pointer++ )
            {
                if (_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[write_pointer] != 0x3FFF)
                {
                    // non - 3FFF value found, increment stop address
                    write_stop = write_pointer;
                }

            }

            //// ensure we do not break 8 word rule, round to lower  value
            write_stop = write_stop & 0xFFF8;

            //DisplayBox.Text += "Writing 0x" + Convert.ToString(START_ADDR, 16) + " to 0x" + Convert.ToString(write_stop,16) + "." + Environment.NewLine;
            DisplayBox.Text += "Downloading data...";

            progressBar.Maximum = write_stop ;
            progressBar.Minimum = START_ADDR;
            // Set the address pointer to start of memory region
            Bootload.Set_Address_Pointer(START_ADDR);
            for (int a = write_start; a <= write_stop; a += 8)
            {
                Bootload.Send_Data_Chunk(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory, a);
                if (!Bootload.Write_Cycle())
                {
                    DisplayBox.Text += "Download fail.\n";
                    return;
                }
                WorkingStatus(true, a / 8);
                progressBar.Value = a;
            }
            WorkingStatus(false, 0);

            // write last row, keep the flag out for now
            WriteLastRow(false);

            DisplayBox.Text += "done." + Environment.NewLine;
            progressBar.Value = write_start;
            
            DisplayBox.Text += "Verifying...." + Environment.NewLine;

            int errorAtAddress =0 ;
            Bootload.Set_Address_Pointer(write_start);
            for (int a = write_start; a < write_stop; a += 8)
            {
                
                if (Bootload.Verify_Data_Chunk(_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory, a, ref  errorAtAddress))
                {

                }
                else
                {
                    DisplayBox.Text += "Found an error at address: 0x" + Convert.ToString(errorAtAddress,16)+ Environment.NewLine;
                    return;

                }
                WorkingStatus(true, a / 8);
                progressBar.Value = a;
            }
            progressBar.Value = write_start;
            WorkingStatus(false, 0);
            if (VerifyLastRow())
                DisplayBox.Text += "done." + Environment.NewLine;
            else
            {
                DisplayBox.Text += "Error writing last row." + Environment.NewLine;
                return;
            }

            // everything went ok , come back and write the flag
            WriteLastRow(true);


            DisplayBox.Text += "Firmware download complete." + Environment.NewLine;
        }
        private void EraseAll()
        {
            progressBar.Maximum = STOP_ADDR - 1;
            progressBar.Minimum = START_ADDR;
           
            if (Bootload.Set_Address_Pointer(START_ADDR))
            {
                for (int a = START_ADDR; a < STOP_ADDR; a += 32)
                {
                    Bootload.Erase_Cycle();
                    progressBar.Value = a;
                    WorkingStatus(true, a / 32);
                }
                progressBar.Value = START_ADDR;

            }
            WorkingStatus(false, 0);
            DisplayBox.Text +="done."+ Environment.NewLine;
        }
        private void WriteLastRow(bool bootflag)
        {
            uint[] data = new uint[64];

            // Position to last flag
            // STOP_ADDR will contain the last address
            Bootload.Set_Address_Pointer(STOP_ADDR - 7);

            for (int a = 0; a < 7; a++)
            {
                data[a] = _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[(STOP_ADDR - 7) + a];
            }
                if ( bootflag )
                    data[7] = _1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[STOP_ADDR];
                else
                    data[7] = 0x3FFF;  // we leave out the flag for now
            Bootload.Send_Data_Chunk(data, 0);
            Bootload.Write_Cycle();

        }
        private bool VerifyLastRow()
        {
            int[] DataArray = new int[8];
            bool result = true;

            Bootload.Set_Address_Pointer(STOP_ADDR - 7);
            Bootload.Read_Data(ref DataArray);

            for (int a = 0; a <= 6; a++)
            {

                if (_1937_Bootloader.ImportExportHex.DeviceBuffers.ProgramMemory[(STOP_ADDR - 7 ) + a] == DataArray[a])
                {

                }
                else
                {
                    result = false;
                    break;
                }
            }
            return result;

        }
        #endregion


    }
}