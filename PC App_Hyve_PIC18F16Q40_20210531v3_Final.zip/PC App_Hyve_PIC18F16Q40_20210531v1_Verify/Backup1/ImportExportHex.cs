/*********************************************************************
* FileName:		   ImportExportHex.cs
* Dependencies:    See INCLUDES section below
* Processor:       
* Compiler:        
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description:
*
* Change History:
* Author               Cristian Toma
********************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace _1937_Bootloader
{
    class ImportExportHex
    {
        public static DateTime LastWriteTime = new DateTime();
        public static DeviceData DeviceBuffers = new DeviceData(0x2000, 256, 0x02, 0x04, 0x3FFF, 256, 4); 

//       public static DeviceData DeviceBuffers = new DeviceData();

        public static bool ImportHexFile(String filePath/*, bool progMem, bool eeMem*/)
        {  // NOTE: The device buffers being read into must all be set to blank value before getting here!

            try
            {
                FileInfo hexFile = new FileInfo(filePath);
                LastWriteTime = hexFile.LastWriteTime;
                TextReader hexRead = hexFile.OpenText();


 //               int numar_de_linii = 0;

                int  bytesPerWord = 2;   // PIC16, 14 bit word
                int  eeMemBytes = 2;
                uint eeAddr = 0x4200; // aici mapeaza EEPROM ( adresa in bytes)
                int  progMemSizeBytes = 8192 * bytesPerWord;
                int  segmentAddress = 0;
                //bool configRead = false;
                bool lineExceedsFlash = false;
                bool fileExceedsFlash = false;
                //int  userIDs = 4;
                //uint userIDAddr = 0x8000;

                //int  userIDMemBytes = 8;
                // need to set config words to memory blank.
                int  configWords = 2;
                bool[] configLoaded = new bool[configWords];

                int  cfgBytesPerWord = bytesPerWord;
                uint programMemStart = 0;

                string fileLine = hexRead.ReadLine();
                while (fileLine != null)
                {
                    if ((fileLine[0] == ':') && (fileLine.Length >= 11))
                    { // skip line if not hex line entry,or not minimum length ":BBAAAATTCC"

                        int byteCount = Int32.Parse(fileLine.Substring(1, 2), System.Globalization.NumberStyles.HexNumber);
                        int fileAddress = segmentAddress + Int32.Parse(fileLine.Substring(3, 4), System.Globalization.NumberStyles.HexNumber);
                        int recordType = Int32.Parse(fileLine.Substring(7, 2), System.Globalization.NumberStyles.HexNumber);

                        if (recordType == 0)
                        { // Data Record}
                            if (fileLine.Length >= (11 + (2 * byteCount)))
                            { // skip if line isn't long enough for bytecount.                    

                                for (int lineByte = 0; lineByte < byteCount; lineByte++)
                                {
                                    int byteAddress = fileAddress + lineByte;
                                    // compute array address from hex file address # bytes per memory location
                                    int arrayAddress = (byteAddress - (int)programMemStart) / bytesPerWord;
                                    // compute byte position withing memory word
                                    int bytePosition = byteAddress % bytesPerWord;
                                    // get the byte value from hex file
                                    uint wordByte = 0xFFFFFF00 | UInt32.Parse(fileLine.Substring((9 + (2 * lineByte)), 2), System.Globalization.NumberStyles.HexNumber);
                                    //uint wordByte = UInt32.Parse(fileLine.Substring((9 + (2 * lineByte)), 2), System.Globalization.NumberStyles.HexNumber);

                                    // shift the byte into its proper position in the word.
                                    for (int shift = 0; shift < bytePosition; shift++)
                                    { // shift byte into proper position
                                        wordByte <<= 8;
                                        wordByte |= 0xFF; // shift in ones.
                                    }

                                    lineExceedsFlash = true; // if not in any memory section, then error

                                    



                                    // program memory section --------------------------------------------------
                                    if ((byteAddress >= programMemStart) && (byteAddress < progMemSizeBytes))
                                    {
                                        DeviceBuffers.ProgramMemory[arrayAddress] &= wordByte;// add byte

                                        lineExceedsFlash = false;
                                        //NOTE: program memory locations containing config words may get modified
                                        // by the config section below that applies the config masks.
                                    }

                                    //if (byteAddress >= 0x43FC) 
                                    //    MessageBox.Show("S-a terminat eeprom");

                                    // EE data section ---------------------------------------------------------
                                    if ((byteAddress >= eeAddr) && (eeAddr > 0) && (eeMemBytes > 0))
                                    {
                                        int eeAddress = (int)(byteAddress - eeAddr) / eeMemBytes;

                                        lineExceedsFlash = false;
                                        if (eeMemBytes == bytesPerWord)
                                        { // same # hex bytes per EE location as ProgMem location
                                            DeviceBuffers.EEPromMemory[eeAddress] &= wordByte; // add byte.    
                                        }
                                        else
                                        {  // PIC18F/J
                                            int eeshift = (bytePosition / eeMemBytes) * eeMemBytes;
                                            for (int reshift = 0; reshift < eeshift; reshift++)
                                            { // shift byte into proper position
                                                wordByte >>= 8;
                                            }
                                            DeviceBuffers.EEPromMemory[eeAddress] &= wordByte; // add byte. 
                                        }
                                    }
                                    // Some 18F parts without EEPROM have hex files created with blank EEPROM by MPLAB
                                    else if ((byteAddress >= eeAddr) && (eeAddr > 0))
                                    {
                                        lineExceedsFlash = false; // don't give too-large file error.
                                    }
                                }
                            }

                            if (lineExceedsFlash)
                            {
                                fileExceedsFlash = true;
                            }

                        } // end if (recordType == 0)  

                        if ((recordType == 2) || (recordType == 4))
                        { // Segment address
                            if (fileLine.Length >= (11 + (2 * byteCount)))
                            { // skip if line isn't long enough for bytecount.                                                    
                                segmentAddress = Int32.Parse(fileLine.Substring(9, 4), System.Globalization.NumberStyles.HexNumber);
                            }
                            if (recordType == 2)
                            {
                                segmentAddress <<= 4;
                            }
                            else
                            {
                                segmentAddress <<= 16;
                            }

                        } // end if ((recordType == 2) || (recordType == 4)) 

                        if (recordType == 1)
                        { // end of record
                            break;
                        }

                    }
                    fileLine = hexRead.ReadLine();
 //                   numar_de_linii++;
                }
 //               MessageBox.Show( "Numar de linii in fisier: " + Convert.ToString(numar_de_linii,10));               
                hexRead.Close();


                if (fileExceedsFlash)
                {
                    return false;
                }
                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool ExportHexFile(string filePath, bool progMem, bool eeMem)
        {
            StreamWriter hexFile = new StreamWriter(filePath);

            int ProgramMemoryLength = 8192;


            hexFile.WriteLine(":020000040000FA");

            // Program Memory ----------------------------------------------------------------------------
            int fileSegment = 0;
            int fileAddress = 0;
            int programEnd = ProgramMemoryLength;
            int arrayIndex = 0;
            int bytesPerWord = 2;
            int arrayIncrement = 16 / bytesPerWord;     // # array words per hex line.
            if (progMem)
            {
                do
                {
                    string hexLine = string.Format(":10{0:X4}00", fileAddress);
                    for (int i = 0; i < arrayIncrement; i++)
                    {
                        // convert entire array word to hex string of 4 bytes.
                        string hexWord = "00000000";
                        if ((arrayIndex + i) < ProgramMemoryLength)
                        {
                            hexWord = string.Format("{0:X8}", DeviceBuffers.ProgramMemory[arrayIndex + i]);
                        }
                        for (int j = 0; j < bytesPerWord; j++)
                        {
                            hexLine += hexWord.Substring((6 - 2 * j), 2);
                        }
                    }
                    hexLine += string.Format("{0:X2}", computeChecksum(hexLine));
                    hexFile.WriteLine(hexLine);

                    fileAddress += 16;
                    arrayIndex += arrayIncrement;

                    // check for segment boundary
                    if ((fileAddress > 0xFFFF) && (arrayIndex < DeviceBuffers.ProgramMemory.Length))
                    {
                        fileSegment += fileAddress >> 16;
                        fileAddress &= 0xFFFF;
                        string segmentLine = string.Format(":02000004{0:X4}", fileSegment);
                        segmentLine += string.Format("{0:X2}", computeChecksum(segmentLine));
                        hexFile.WriteLine(segmentLine);

                    }

                } while (arrayIndex < programEnd);
            }

            // EEPROM -------------------------------------------------------------------------------------
            if (eeMem)
            {
                int eeSize = DeviceBuffers.EEPromMemory.Length;
                arrayIndex = 0;
                if (eeSize > 0)
                {
                    uint eeAddr = 0x4200;
                    if ((eeAddr & 0xFFFF0000) > 0)
                    { // need a segment address
                        string segmentLine = string.Format(":02000004{0:X4}", (eeAddr >> 16));
                        segmentLine += string.Format("{0:X2}", computeChecksum(segmentLine));
                        hexFile.WriteLine(segmentLine);
                    }

                    fileAddress = (int)eeAddr & 0xFFFF;
                    int eeBytesPerWord = 2;
                    arrayIncrement = 16 / eeBytesPerWord;     // # array words per hex line.
                    do
                    {
                        string hexLine = string.Format(":10{0:X4}00", fileAddress);
                        for (int i = 0; i < arrayIncrement; i++)
                        {
                            // convert entire array word to hex string of 4 bytes.
                            string hexWord = string.Format("{0:X8}", DeviceBuffers.EEPromMemory[arrayIndex + i]);
                            for (int j = 0; j < eeBytesPerWord; j++)
                            {
                                hexLine += hexWord.Substring((6 - 2 * j), 2);
                            }
                        }
                        hexLine += string.Format("{0:X2}", computeChecksum(hexLine));
                        hexFile.WriteLine(hexLine);

                        fileAddress += 16;
                        arrayIndex += arrayIncrement;
                    } while (arrayIndex < DeviceBuffers.EEPromMemory.Length);

                }
            }
            //// Configuration Words ------------------------------------------------------------------------
            //if (progMem)
            //{
            //    int cfgBytesPerWord = bytesPerWord;

            //    int configWords = Pk2.DevFile.PartsList[Pk2.ActivePart].ConfigWords;
            //    if ((configWords > 0) && (Pk2.DevFile.PartsList[Pk2.ActivePart].ConfigAddr >
            //        (Pk2.DevFile.PartsList[Pk2.ActivePart].ProgramMem * bytesPerWord)))
            //    { // If there are Config words and they aren't at the end of program flash
            //        uint configAddr = Pk2.DevFile.PartsList[Pk2.ActivePart].ConfigAddr;
            //        if ((configAddr & 0xFFFF0000) > 0)
            //        { // need a segment address
            //            string segmentLine = string.Format(":02000004{0:X4}", (configAddr >> 16));
            //            segmentLine += string.Format("{0:X2}", computeChecksum(segmentLine));
            //            hexFile.WriteLine(segmentLine);
            //        }

            //        fileAddress = (int)configAddr & 0xFFFF;

            //        int cfgsWritten = 0;
            //        for (int lines = 0; lines < (((configWords * cfgBytesPerWord - 1) / 16) + 1); lines++)
            //        {
            //            int cfgsLeft = configWords - cfgsWritten;
            //            if (cfgsLeft >= (16 / cfgBytesPerWord))
            //            {
            //                cfgsLeft = (16 / cfgBytesPerWord);
            //            }
            //            string hexLine = string.Format(":{0:X2}{1:X4}00", (cfgsLeft * cfgBytesPerWord), fileAddress);
            //            fileAddress += (cfgsLeft * cfgBytesPerWord);
            //            for (int i = 0; i < cfgsLeft; i++)
            //            {
            //                // convert entire array word to hex string of 4 bytes.
            //                uint cfgWord = DeviceBuffers.ConfigWords[cfgsWritten + i];
            //                if (Pk2.DevFile.Families[Pk2.GetActiveFamily()].BlankValue > 0xFFFFFF)
            //                {// PIC32
            //                    cfgWord |= ~(uint)Pk2.DevFile.PartsList[Pk2.ActivePart].ConfigMasks[cfgsWritten + i];
            //                    cfgWord &= Pk2.DevFile.PartsList[Pk2.ActivePart].ConfigBlank[cfgsWritten + i];
            //                }
            //                string hexWord = string.Format("{0:X8}", cfgWord);
            //                for (int j = 0; j < cfgBytesPerWord; j++)
            //                {
            //                    hexLine += hexWord.Substring(8 - ((j + 1) * 2), 2);
            //                }
            //            }
            //            hexLine += string.Format("{0:X2}", computeChecksum(hexLine));
            //            hexFile.WriteLine(hexLine);
            //            cfgsWritten += cfgsLeft;
            //        }
            //    }
            //}

            //// UserIDs ------------------------------------------------------------------------------------
            //if (progMem)
            //{
            //    int userIDs = Pk2.DevFile.PartsList[Pk2.ActivePart].UserIDWords;
            //    arrayIndex = 0;
            //    if (userIDs > 0)
            //    {
            //        uint uIDAddr = Pk2.DevFile.PartsList[Pk2.ActivePart].UserIDAddr;
            //        if ((uIDAddr & 0xFFFF0000) > 0)
            //        { // need a segment address
            //            string segmentLine = string.Format(":02000004{0:X4}", (uIDAddr >> 16));
            //            segmentLine += string.Format("{0:X2}", computeChecksum(segmentLine));
            //            hexFile.WriteLine(segmentLine);
            //        }

            //        fileAddress = (int)uIDAddr & 0xFFFF;
            //        int idBytesPerWord = Pk2.DevFile.Families[Pk2.GetActiveFamily()].UserIDHexBytes;
            //        arrayIncrement = 16 / idBytesPerWord;     // # array words per hex line.
            //        string hexLine;
            //        do
            //        {
            //            int remainingBytes = (userIDs - arrayIndex) * idBytesPerWord;
            //            if (remainingBytes < 16)
            //            {
            //                hexLine = string.Format(":{0:X2}{1:X4}00", remainingBytes, fileAddress);
            //                arrayIncrement = (userIDs - arrayIndex);
            //            }
            //            else
            //            {
            //                hexLine = string.Format(":10{0:X4}00", fileAddress);
            //            }
            //            for (int i = 0; i < arrayIncrement; i++)
            //            {
            //                // convert entire array word to hex string of 4 bytes.
            //                string hexWord = string.Format("{0:X8}", DeviceBuffers.UserIDs[arrayIndex + i]);
            //                for (int j = 0; j < idBytesPerWord; j++)
            //                {
            //                    hexLine += hexWord.Substring((6 - 2 * j), 2);
            //                }
            //            }
            //            hexLine += string.Format("{0:X2}", computeChecksum(hexLine));
            //            hexFile.WriteLine(hexLine);

            //            fileAddress += 16;
            //            arrayIndex += arrayIncrement;
            //        } while (arrayIndex < DeviceBuffers.UserIDs.Length);
            //    }
            //}

            //end of record line.
            hexFile.WriteLine(":00000001FF");
            hexFile.Close();
            return true;
        }


        private static byte computeChecksum(string fileLine)
        {
            int byteCount = Int32.Parse(fileLine.Substring(1, 2), System.Globalization.NumberStyles.HexNumber);
            if (fileLine.Length >= (9 + (2 * byteCount)))
            { // skip if line isn't long enough for bytecount.             
                int checksum = byteCount;
                for (int i = 0; i < (3 + byteCount); i++)
                {
                    checksum += Int32.Parse(fileLine.Substring(3 + (2 * i), 2), System.Globalization.NumberStyles.HexNumber);
                }
                checksum = 0 - checksum;
                return (byte)(checksum & 0xFF);
            }

            return 0;
        }
    }
}
