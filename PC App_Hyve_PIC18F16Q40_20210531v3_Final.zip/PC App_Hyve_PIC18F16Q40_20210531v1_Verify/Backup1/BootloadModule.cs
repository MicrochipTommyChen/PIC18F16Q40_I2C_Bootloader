﻿/*********************************************************************
* FileName:        BootloadModule.cs
* Dependencies:    See INCLUDES section below
* Processor:       
* Compiler:        
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro® Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description:
*
* Change History:
* Author               Cristian Toma
********************************************************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
namespace _1937_Bootloader
{
    class Bootload
    {
        public static bool InitTransport(int transport)
        {
            if (PICkitS.Basic.Initialize_PICkitSerial())
            {
                if (PICkitS.I2CM.Configure_PICkitSerial_For_I2CMaster())
                {
                    PICkitS.Basic.Reset_Control_Block();
                    PICkitS.I2CM.Set_I2C_Bit_Rate(400000);
                    PICkitS.I2CM.Set_Receive_Wait_Time(200);
                    return true;
                }
                return false;
            }
            return false;
        }
        public static bool Set_Address_Pointer(int address)
        {
            byte slave_address = 0xA0;      // device's address
            byte word_address = 0x01;       // word address for tx buffer
            byte[] DataArray = new byte[2];
            byte bytes_to_write = 0x02;
            string Return_Str = "";


            byte Byte0 = (byte)(address >> 8);        // high byte
            byte Byte1 = (byte)(address & 0xFF);      // low  byte

            DataArray[0] = Byte0;
            DataArray[1] = Byte1;
            try
            {
                if (PICkitS.I2CM.Write(slave_address, word_address, bytes_to_write, ref DataArray, ref Return_Str))
                {
                }
                else
                {
                    PICkitS.Basic.Reset_Control_Block(); //   clear any errors in PKSA
                    return false;
                }
            }
            catch
            {
                return false;
            }

            return true;
        }
        public static bool Get_Address_Pointer(ref int address)
        {

            byte slave_address = 0xA0;      // device's address
            byte word_address = 0x01;       // word address for tx buffer
            byte[] DataArray = new byte[2];
            byte bytes_to_read = 0x02;
            string Return_Str = "";
            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                    address = DataArray[0] * 256 + DataArray[1];
                }
                else
                {
                   return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }

            return true;
        }
        public static bool Read_Data(ref int[] data)
        {
            byte slave_address = 0xA0;      // device's address
            byte word_address = 0x03;       // read flash command
            byte[] DataArray = new byte[64];
            byte bytes_to_read = 16;
            string Return_Str = "";

            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                    data[0] = DataArray[0] * 256 + DataArray[1];
                    data[1] = DataArray[2] * 256 + DataArray[3];
                    data[2] = DataArray[4] * 256 + DataArray[5];
                    data[3] = DataArray[6] * 256 + DataArray[7];
                    data[4] = DataArray[8] * 256 + DataArray[9];
                    data[5] = DataArray[10] * 256 + DataArray[11];
                    data[6] = DataArray[12] * 256 + DataArray[13];
                    data[7] = DataArray[14] * 256 + DataArray[15];
                }
                else
                {
                    return false;
                }
            } 
            catch
            {
                    PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                    return false;
            }
            return true;
        }
        public static bool Erase_Cycle()
        {
            byte slave_address = 0xA0;      // device's address
            byte word_address = 0x04;       // word address for tx buffer
            byte[] DataArray = new byte[64];
            byte bytes_to_read = 1;
            string Return_Str = "";

            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }
            return true;
        }
        public static bool Write_Cycle()
        {
            byte slave_address = 0xA0;      // device's address
            byte word_address = 0x05;       // write command
            byte[] DataArray = new byte[64];
            byte bytes_to_read = 1;
            string Return_Str = "";

            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }
            return true;

        }
        public static bool Send_Data_Chunk(uint[] data, int address)
        {
            byte slave_address = 0xA0;      // device's address
            byte word_address = 0x02;       // download 8 word to buffer
            byte bytes_to_write = 16;
            string Return_Str = "";
            byte[] Array = new byte[64];

            Array[0] = Convert.ToByte(data[address + 0] >> 8);
            Array[1] = Convert.ToByte(data[address + 0] & 0xFF);
            Array[2] = Convert.ToByte(data[address + 1] >> 8);
            Array[3] = Convert.ToByte(data[address + 1] & 0xFF);
            Array[4] = Convert.ToByte(data[address + 2] >> 8);
            Array[5] = Convert.ToByte(data[address + 2] & 0xFF);
            Array[6] = Convert.ToByte(data[address + 3] >> 8);
            Array[7] = Convert.ToByte(data[address + 3] & 0xFF);
            Array[8] = Convert.ToByte(data[address + 4] >> 8);
            Array[9] = Convert.ToByte(data[address + 4] & 0xFF);
            Array[10] = Convert.ToByte(data[address + 5] >> 8);
            Array[11] = Convert.ToByte(data[address + 5] & 0xFF);
            Array[12] = Convert.ToByte(data[address + 6] >> 8);
            Array[13] = Convert.ToByte(data[address + 6] & 0xFF);
            Array[14] = Convert.ToByte(data[address + 7] >> 8);
            Array[15] = Convert.ToByte(data[address + 7] & 0xFF);

            try
            {
                if (PICkitS.I2CM.Write(slave_address, word_address, bytes_to_write, ref Array, ref Return_Str))
                {
                    return true;
                }
                else
                {
                    PICkitS.Basic.Reset_Control_Block(); //   clear any errors in PKSA
                    return false;
                }
            }
            catch
            {
                return false;
            }           
        }
        public static bool Verify_Data_Chunk(uint[] data, int address, ref int  errorAddress)
        {
            int[] DataArray = new int[8];
            byte a = 0;
            bool result =  true;

            Read_Data(ref DataArray);
            for (a = 0; a <= 7; a++)
            {
                
                if (data[address + a] == DataArray[a])
                {

                }
                else
                {
                    errorAddress = address + a;
                    //MessageBox.Show("address + a = " + (address + a ));
                    //MessageBox.Show("a " + DataArray[a]);
                    result = false;
                    break;
                }
            }
            return result;
        }
        public static bool Go_To_App_Mode()
        {
            byte slave_address = 0xA0;      // device's address
            byte word_address = 0x06;       // jump to application code
            byte[] DataArray = new byte[64];
            byte bytes_to_read = 1;
            string Return_Str = "";


            try
            {
                if (PICkitS.I2CM.Read(slave_address, word_address, bytes_to_read, ref DataArray, ref Return_Str))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                PICkitS.Basic.Reset_Control_Block();  //clear any errors in PKSA
                return false;
            }
        }
    }
}
